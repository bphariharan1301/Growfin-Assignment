import React from "react";
import { Button, Grid, Typography } from "@mui/material";
// import logo from "./path-to-your-logo"; // Import your logo image here

const HeroSection = () => {
	return (
		<div className="bg-gradient-to-r from-gradient-start to-gradient-end text-white py-16 px-8">
			<Grid
				container
				spacing={4}
				alignItems="center"
				justifyContent="space-between"
			>
				{/* Logo Section */}
				<Grid item>
					<img src={"Logo"} alt="Logo" className="h-12 md:h-16" />
				</Grid>

				{/* Button Section */}
				<Grid item>
					<div className="flex space-x-4">
						<Button
							variant="contained"
							className="bg-teal-500 text-white px-6 py-2 rounded-full"
						>
							Schedule a Demo
						</Button>
						<Button
							variant="outlined"
							className="border-cyan-400 text-cyan-400 px-6 py-2 rounded-full"
							sx={{ borderColor: "#00D8FF", color: "#00D8FF" }}
						>
							Request Access
						</Button>
					</div>
				</Grid>
			</Grid>

			<Grid container spacing={4} className="mt-12">
				<Grid item xs={12} md={6}>
					<Typography variant="h2" component="h1" className="font-bold mb-4">
						Real-Time Cash Application Software
					</Typography>
					<Typography variant="body1" className="mb-8">
						Radically minimize manual intervention and achieve same-day closure
						with Growfin’s ML-powered Cash Application that delivers accurate,
						touchless posting.
					</Typography>
					<div className="flex space-x-4">
						<Button
							variant="contained"
							className="bg-teal-500 text-white px-6 py-2 rounded-full"
						>
							Schedule a Demo
						</Button>
						<Button
							variant="outlined"
							className="border-cyan-400 text-cyan-400 px-6 py-2 rounded-full"
							sx={{ borderColor: "#00D8FF", color: "#00D8FF" }}
						>
							Request Access
						</Button>
					</div>
				</Grid>

				{/* Image Section */}
				<Grid
					item
					xs={12}
					md={6}
					className="flex justify-center md:justify-end"
				>
					<img
						src="path-to-your-image"
						alt="Software Screenshot"
						className="max-w-full h-auto"
					/>
				</Grid>
			</Grid>
		</div>
	);
};

export default HeroSection;
