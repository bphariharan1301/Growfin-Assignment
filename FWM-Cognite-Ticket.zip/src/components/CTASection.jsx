import React from "react";
import { Button, Typography } from "@mui/material";

const CTASection = () => {
	return (
		<div className="bg-gradient-to-r from-gradient-start to-gradient-end text-white py-16 px-8 flex flex-col items-center text-center rounded-lg mx-auto max-w-4xl">
			<Typography variant="h4" component="h2" className="font-bold mb-8">
				Embrace the Future of Cash Application Today
			</Typography>
			<div className="flex space-x-4">
				<Button
					variant="contained"
					className="bg-teal-500 text-white px-6 py-2 rounded-full"
				>
					Schedule a Demo
				</Button>
				<Button
					variant="outlined"
					className="border-cyan-400 text-cyan-400 px-6 py-2 rounded-full"
					sx={{ borderColor: "#00D8FF", color: "#00D8FF" }}
				>
					Request Access
				</Button>
			</div>
		</div>
	);
};

export default CTASection;
